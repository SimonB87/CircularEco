# Circular Economy Social Website
## Website for sharing proposal on the topic of circular economy.
*This site should support generation of propoject proposals for decresing waste production in towns.*
*This project is supported by the TACR agency as a project TL01000217 executed in period 2018-2020*

This is link to the [Social website](http://simonburyan.cz/circ/register.php).

Current: Section 7 Lecture 51.

LocalHost version: database archive provided as for Lesson 50!
