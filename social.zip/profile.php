<?php
include("includes/header.php");

/*destroy all the log ins after refresh
session_destroy();*/

?>


	<div class="main_column column">
    Thi is profile page.

</div> <!-- closing of the wrapper div, this div stars in the included header file-->

</body>
</html>
